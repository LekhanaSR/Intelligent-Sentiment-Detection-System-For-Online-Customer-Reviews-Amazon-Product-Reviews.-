import pandas as pd
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import zipfile
import seaborn as sns
import matplotlib.pyplot as plt

# Extract the zip file
zip_path = 'C:\\Users\\Lekhana S R\\Downloads\\sentiment+labelled+sentences.zip'
extract_path = 'C:\\Users\\Lekhana S R\\Downloads\\sentiment+labelled+sentences'

with zipfile.ZipFile(zip_path, 'r') as zip_ref:
    zip_ref.extractall(extract_path)

# Load the dataset (Amazon reviews)
file_path = extract_path + '\\sentiment labelled sentences\\amazon_cells_labelled.txt'
df = pd.read_csv(file_path, sep='\t', names=['review', 'sentiment'], encoding="ISO-8859-1")

# Print the first few rows
print("Dataset Preview:\n", df.head())

# Check for missing values
print("\nMissing values:\n", df.isnull().sum())

# Preprocess the text data
def preprocess_text(text):
    if isinstance(text, str):  # Ensure text is a string
        text = text.lower()  # Convert to lowercase
        text = re.sub(r'\d+', '', text)  # Remove numbers
        text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
        text = re.sub(r'\s+', ' ', text).strip()  # Remove extra spaces
        return text
    return ""

df['review'] = df['review'].apply(preprocess_text)

# Check for empty reviews after preprocessing
df = df[df['review'].str.strip() != ""]

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(df['review'], df['sentiment'], test_size=0.2, random_state=42, stratify=df['sentiment'])

# Create a TF-IDF vectorizer with stop word removal and min_df=2 to avoid empty vocabulary errors
vectorizer = TfidfVectorizer(stop_words="english", min_df=2)

X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)

# Train a Naive Bayes classifier
clf = MultinomialNB()
clf.fit(X_train_tfidf, y_train)

# Make predictions on the test set
y_pred = clf.predict(X_test_tfidf)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print("\nModel Accuracy:", accuracy)
print("\nClassification Report:\n", classification_report(y_test, y_pred))

# Generate confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)

# Plot the heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=["Negative", "Positive"], yticklabels=["Negative", "Positive"])
plt.title('Confusion Matrix Heatmap')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()
